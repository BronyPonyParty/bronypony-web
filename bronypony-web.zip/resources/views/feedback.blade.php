Пользователь {{ $user }} с почтой {{ $mail  }} пишет {{ $description }}
