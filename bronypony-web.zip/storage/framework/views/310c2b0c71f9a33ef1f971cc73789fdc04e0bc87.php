Тестовое сообщение!
<?php /**PATH C:\Users\Brony\Documents\GitHub\bronypony-web\resources\views/mail.blade.php ENDPATH**/ ?>